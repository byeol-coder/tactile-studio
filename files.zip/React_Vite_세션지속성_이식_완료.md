# React+Vite 브랜치 — 세션 지속성(그룹 A) 이식 완료

- **브랜치**: `agent/tactile-studio-react-migration`
- **작업 순서**: 우선순위 자동 결정 → A(세션 지속성)부터 진행
- **최종 상태**: 5개 커밋, 전체 스위트 210/210, `tsc --noEmit` 클린, CI와 동일한 게이트(x-dc 구문·대비·빌드) 전부 로컬 재현 통과

---

## 왜 코드부터 안 보고 "동기화"부터 했나

패리티 테스트(`tools/harness.mjs`)는 "실제 배포 소스와 바이트 단위로 비교"가 핵심 신뢰 장치인데, 이 브랜치에 박혀있는 `index.html` 참조본이 **fork 시점(7/10)에 멈춰 있어 최신 main(7/13, 17커밋)과 900줄 넘게 벌어져 있었어요.** 이 상태로 새 기능을 이식하면 "패리티 테스트 통과"가 사실은 3일 전 코드와의 패리티일 뿐이라 의미가 없어져서, 먼저 최신화부터 했습니다.

동기화하다 **진짜 충돌 하나**를 발견했어요: `banaPrintCheck`가 이 마이그레이션 브랜치 자체(Phase 1, fork 이전)에서 한 번 고쳐졌고, vanilla main에서도 **서로 전혀 모른 채** 독립적으로 또 고쳐졌는데(`addd43a`, 7/13), 반환 형태가 달랐어요(`{issues:[]}` vs `{key:string}`). 실사용처는 `.pass`만 읽어서 안전하게 vanilla의 실제 형태로 맞췄습니다.

## 세션 지속성 이식 — 무엇을 만들었나

vanilla가 `ecb67e3`(7/13)에서 추가한 "새로고침해도 안 잃어버리는" 기능 전체를 처음으로 이식했어요:

| 계층 | 파일 | 내용 |
|---|---|---|
| 순수 코덱 | `codecs/document/session-snapshot.ts` | pack/unpack(base64 비트패킹), hasContent 판정, serialize/parse — vanilla 실제 메서드와 **패리티 테스트 6개**로 검증 |
| 스토리지 | `storage/adapters/session-recovery-storage-adapter.ts` | localStorage 실 어댑터(`ts.session.v1`) — **테스트 7개** |
| 상태관리 | `core/state/editor-store.ts` | 800ms 디바운스 자동저장(모든 편집마다 리셋), 복구 체크/적용/거부/dispose — **테스트 8개** |
| React 배선 | `TactileStudioProvider`/`TactileStudioEditor` | 마운트 시 복구 스냅샷 확인(mutate 이전), 언마운트 시 타이머 정리, 기본 어댑터 자동 주입 |
| UI | `ui/recovery/RecoveryBanner.tsx` | vanilla 배너 마크업 미러 (단, 임베드 컴포넌트 특성상 `position:fixed`로 조정) — **엔드투엔드 테스트 4개** |

**설계 결정 하나**: 로컬 라이브러리 어댑터(#7)와 달리, 이번엔 vanilla의 무음 실패 버그를 그대로 재현하지 않고 **처음부터 boolean 반환 계약으로 올바르게** 만들었어요. 이 브랜치엔 참조할 "이전 버전"이 없었으니, verbatim 이식의 대상 자체가 없었거든요.

**부수적으로 하네스 자체도 보강**: `tools/harness.mjs`의 vm 샌드박스에 `btoa`/`atob`가 없어서 첫 테스트가 전부 실패했어요 — 이 기능이 base64를 쓰는 첫 번째 이식 대상이라 처음 드러난 gap이었습니다.

## 검증

- 신규 25개 테스트 + 기존 185개 = **210/210**
- `tsc --noEmit` 클린
- `npm run check:xdc-syntax` / `check:contrast` (CI와 동일 게이트) 클린
- `vite build`(dev-shell) + `vite build --config vite.lib.config.ts`(배포 패키지) 둘 다 성공
- vanilla 파일(index.html/support.js/vendor/corpus*) 이번 커밋들에서 변경 없음 확인(동기화 커밋 자체는 예외, 의도된 변경)

## 커밋 (5개, `git am` 순서대로 적용)

1. `fix(storage): report local-library save failures instead of swallowing them` (#7 일부, 이전 세션분)
2. `docs(known-issues): audit ...` (#8, 이전 세션분)
3. `chore(sync): refresh frozen vanilla reference to main HEAD 29ef81f; reconcile banaPrintCheck shape`
4. `feat(studio): port crash-recovery session autosave from vanilla ecb67e3`
5. `docs(known-issues): mark #7's session-recovery gap resolved`

## 남은 것 (17커밋 중 A 완료, B/C/D/E 남음)

| 그룹 | 상태 |
|---|---|
| A. 세션 지속성 | ✅ 완료 |
| B. 이미지 변환 마법사 재설계 (4→2단계) | 남음 |
| C. 편집기 신규 기능 (페이지 복제, DotPad 재연결 상태, 멀티포인터 가드) | 남음 |
| D. 실제 엠보싱 인쇄 내보내기 (A4@300dpi) | 남음 |
| E. 저비용 정리 | 남음 |

다음은 B로 넘어갈게요.
